//
// Created by Мария Корогодова on 20.01.2021.
//

#include "NinjaTrap.hpp"

NinjaTrap::NinjaTrap()
{
	this->_name = "default";
//	this->_hitPoints = 60;
//	this->_maxHitPoints = 60;
//	this->_energyPoints = 120;
//	this->_maxEnergyPoints = 120;
//	this->_meleeAttackDamage = 60;
//	this->_rangedAttackDamage = 5;
//	this->_armorDamageReduction = 0;
	set_hitPoints(60);
	set_maxHitPoints(60);
	set_energyPoints(120);
	set_maxEnergyPoints(120);
	set_meleeAttackDamage(60);
	set_rangedAttackDamage(5);
	set_armorDamageReduction(0);
	std::cout << "NinjaTrap I'm over here! (created)" << std::endl << std::endl;
}

NinjaTrap::NinjaTrap(std::string const name): ClapTrap(name)
{
	set_hitPoints(60);
	set_maxHitPoints(60);
	set_energyPoints(120);
	set_maxEnergyPoints(120);
	set_meleeAttackDamage(60);
	set_rangedAttackDamage(5);
	set_armorDamageReduction(0);
//	this->_hitPoints = 60;
//	this->_maxHitPoints = 60;
//	this->_energyPoints = 120;
//	this->_maxEnergyPoints = 120;
//	this->_meleeAttackDamage = 60;
//	this->_rangedAttackDamage = 5;
//	this->_armorDamageReduction = 0;
	std::cout << "NinjaTrap " << "\"So fresh, so clean/ My name is " << this->_name << "\" (created)" << std::endl<< std::endl;;
}

NinjaTrap::~NinjaTrap()
{
	std::cout << "NinjaTrap " << this->_name << " \"Oh no\" (killed)" << std::endl;
}

NinjaTrap::NinjaTrap(const NinjaTrap &copy): ClapTrap(copy._name)
{
	*this = copy;
	std::cout << "NinjaTrap " <<  this->_name << " \"I am copy\"" << std::endl;
}

NinjaTrap & NinjaTrap::operator=(const NinjaTrap &op)
{
	ClapTrap::operator=(op);
	return *this;
}

void NinjaTrap::print(ClapTrap *tr)
{
	std::cout << "Test output: " << tr->getName() << ". Go to sleep after this project meh" << std::endl << std::endl;
}

void NinjaTrap::ninjaShoebox(ClapTrap &tr)
{
	std::cout << "-----ClapTrap!-----" << std::endl;
	print(&tr);
}

void NinjaTrap::ninjaShoebox(FragTrap &tr)
{
	std::cout << "-----FragTrap!-----" << std::endl;
	print(&tr);
}

void NinjaTrap::ninjaShoebox(ScavTrap &tr)
{
	std::cout << "-----ScavTrap!-----" << std::endl;
	print(&tr);
}

void NinjaTrap::ninjaShoebox(NinjaTrap &tr)
{
	std::cout << "-----NinjaTrap!-----" << std::endl;
	print(&tr);
}